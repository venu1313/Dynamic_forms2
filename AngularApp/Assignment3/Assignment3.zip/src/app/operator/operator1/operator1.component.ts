import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operator1',
  templateUrl: './operator1.component.html',
  styleUrls: ['./operator1.component.css']
})
export class Operator1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
