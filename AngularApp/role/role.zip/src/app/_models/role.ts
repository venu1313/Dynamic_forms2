﻿export enum Role {
    User = 'User',
    Admin = 'Admin',
    Manager='Manager',
    Opeartor='Operator',
    Supervisor='Supervisor'
}