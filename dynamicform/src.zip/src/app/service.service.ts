import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Isales } from './data';
import { Observable } from 'rxjs';

import { DropdownQuestion } from './question-dropdown';
import { QuestionBase }     from './question-base';
import { TextboxQuestion }  from './question-textbox';
import { of } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  
  private url1:string="/assets/data.json"

  constructor(private http:HttpClient) { }
  getdata():Observable<Isales[]>{
    return this.http.get<Isales[]>(this.url1);
  }


  getQuestions() {

    let questions: QuestionBase<string>[] = [

      // new DropdownQuestion({
      //   key: 'brave',
      //   label: 'Bravery Rating',
      //   options: [
      //     {key: 'solid',  value: 'Solid'},
      //     {key: 'great',  value: 'Great'},
      //     {key: 'good',   value: 'Good'},
      //     {key: 'unproven', value: 'Unproven'}
      //   ],
      //   order: 3
      // }),

      new TextboxQuestion({
        key: 'firstName',
        label: 'First name',
        value: 'Bombasto',
        required: true,
        order: 1
      }),
      new TextboxQuestion({
        key: 'LastName',
        label: 'Lastname',
        // value: 'Bombasto',
        required: true,
        order: 3
      }),

      new TextboxQuestion({
        key: 'emailAddress',
        label: 'Email',
        type: 'email',
        required: true,
        order: 4
      }),
      new TextboxQuestion({
        key: 'Mobile',
        label: 'Moblie',
        type: 'number',
        required: true,
        order: 5
      })
    ];

    return of(questions.sort((a, b) => a.order - b.order));
  }


  toFormGroup(questions: QuestionBase<string>[] ) {
    let group: any = {};

    questions.forEach(question => {
      group[question.key] = question.required ? new FormControl(question.value || '', Validators.required)
                                              : new FormControl(question.value || '');
    });
    return new FormGroup(group);
  }

}
