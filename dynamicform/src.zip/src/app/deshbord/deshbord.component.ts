import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deshbord',
  templateUrl: './deshbord.component.html',
  styleUrls: ['./deshbord.component.css']
})
export class DeshbordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
