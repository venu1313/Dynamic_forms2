var form=document.querySelector('form')

form.addEventListener('submit',function(event)
{
    event.preventDefault()
})

function handleForm()
{
    document.getElementById("Button").disabled =true;
    
   var username=document.getElementById('username').value
   var password=document.getElementById('password').value
   var city=document.getElementById('city').value
   var mobile=document.getElementById('mobile').value
   var Gender=document.getElementById('Gender')
   var skill=document.getElementById('skill')
   var cpassword=document.getElementById('cpassword').value
   
   
    if(username=='')
    {
        document.getElementById('username').focus()
        document.getElementById('error').innerHTML='Username is required'
    }
    else if( username.length < 6 || username.length > 15)
    {
        document.getElementById('username').focus()
        document.getElementById('error').innerHTML='Youer username length is : '+username.length+'   should  be contain minimum 6 characters and max 15 characters' 
    }
    else if(password=='')
    {
        document.getElementById('password').focus()
        document.getElementById('error').innerHTML='Password is required' 
    }
    else if(cpassword=='')
    {
        document.getElementById('cpassword').focus()
        document.getElementById('error').innerHTML='Confrom Password is required' 
    }
     
    else if(!(cpassword==password)) 
    {
             document.getElementById('cpassword').focus()
             document.getElementById('error').innerHTML='Password is does not match' 
          
    }
    else if(mobile=='')
    {
        document.getElementById('mobile').focus()
        document.getElementById('error').innerHTML='mobile is required' 
    }
    else if( mobile.length < 10 || mobile.length > 10)
    {
        document.getElementById('mobile').focus()
        document.getElementById('error').innerHTML='mobile number should  be contain total 10 digits' 
    }
    else if(city=='')
    {
        document.getElementById('city').focus()
        document.getElementById('error').innerHTML='City is required' 
    }
    else if(Gender=='')
    {
        document.getElementById('Gender').focus()
        document.getElementById('error').innerHTML='Gender is required' 
    }
    else if(Gender=='')
    {
        document.getElementById('skill').focus()
        document.getElementById('error').innerHTML='skill is required' 
    }
    else
    {
        console.log('form details captured')
        document.getElementById('error').innerHTML=''
        console.log('username:',username)
        console.log('password:',password)
        console.log('mobile:',mobile)
        console.log('city:',city)
        console.log('Gender:',Gender)
        console.log('skill:',skill)
    }

    
   
}
function handleForm1()
{
    document.getElementById("Button").disabled =false;
}
    




